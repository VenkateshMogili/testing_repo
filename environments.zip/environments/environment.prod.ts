export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBLT0GLlPpyJwc1TOQTt0md59Q1efOaYWM',
    authDomain: 'vchat-messenger.firebaseapp.com',
    databaseURL: 'https://vchat-messenger.firebaseio.com',
    projectId: 'vchat-messenger',
    storageBucket: 'vchat-messenger.appspot.com',
    messagingSenderId: '546055890734'
  }
};
